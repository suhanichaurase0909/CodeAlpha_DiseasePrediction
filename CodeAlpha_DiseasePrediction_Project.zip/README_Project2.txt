
# Disease Prediction Using Machine Learning

CodeAlpha Machine Learning Internship - Project 2

## Objective
Educational classification of breast cancer records
using machine learning algorithms.

## Dataset
Breast Cancer Wisconsin Dataset from Scikit-learn.

## Algorithms
- Logistic Regression
- Random Forest
- Support Vector Machine

## Evaluation
Accuracy, Precision, Recall, F1 Score, ROC-AUC,
Confusion Matrix and ROC Curve.

## Technologies
Python, Pandas, NumPy, Matplotlib, Scikit-learn.

## Important
This is an educational machine learning project.
It is not intended for medical diagnosis or treatment.
